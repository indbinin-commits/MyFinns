# 🌍 MyFinns – Universal Financial Management App

MVP for expense tracking + AI budgeting tips.

---

## 🚀 1‑Click Deploy

### Backend (Node.js + Express)
[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template/8Qa21n?plugins=postgresql)
- Variables:
  ```
  JWT_SECRET=supersecretkey
  PORT=5000
  ```

### AI Service (Python + Flask)
[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template/h1g2l3)
- Variables:
  ```
  PORT=6000
  ```

---

## 📱 Frontend (Expo)
1. Edit `frontend/App.js` URLs after deployment.
2. Start:
```
cd frontend
npm install
npx expo start --tunnel
```
Scan QR in Expo Go app to use on your phone.

---

✅ Backend live  
✅ AI service live  
✅ App available globally  