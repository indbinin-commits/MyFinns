import React, { useState } from "react";
import { View, Text, TextInput, Button, FlatList, SafeAreaView } from "react-native";

const BACKEND_URL = "https://your-backend.up.railway.app"; // replace after deploy
const AI_URL = "https://your-ai.up.railway.app";           // replace after deploy

export default function App() {
  const [category, setCategory] = useState("");
  const [amount, setAmount] = useState("");
  const [expenses, setExpenses] = useState([]);
  const [recommendations, setRecommendations] = useState([]);

  const addExpense = async () => {
    await fetch(`${BACKEND_URL}/expenses`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ category, amount: parseFloat(amount) })
    });
    const res = await fetch(`${BACKEND_URL}/expenses`);
    const data = await res.json();
    setExpenses(data);
  };

  const getRecommendations = async () => {
    const res = await fetch(`${AI_URL}/recommend`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ expenses })
    });
    const data = await res.json();
    setRecommendations(data.recommendations);
  };

  return (
    <SafeAreaView>
      <Text>💰 MyFinns</Text>
      <TextInput placeholder="Category" value={category} onChangeText={setCategory} />
      <TextInput placeholder="Amount" value={amount} onChangeText={setAmount} keyboardType="numeric" />
      <Button title="Add Expense" onPress={addExpense} />
      <Button title="Get Recommendations" onPress={getRecommendations} />
      <Text>Expenses:</Text>
      <FlatList data={expenses} keyExtractor={(item, index) => index.toString()} renderItem={({ item }) => <Text>{item.category}: ${item.amount}</Text>} />
      <Text>AI Tips:</Text>
      {recommendations.map((rec, index) => <Text key={index}>- {rec}</Text>)}
    </SafeAreaView>
  );
}