from flask import Flask, request, jsonify
import os

app = Flask(__name__)

@app.route("/recommend", methods=["POST"])
def recommend():
    data = request.json
    expenses = data.get("expenses", [])
    total_spent = sum(e["amount"] for e in expenses)
    recs = []
    if total_spent > 1000:
        recs.append("Reduce optional spending to boost savings 📉")
    if len(expenses) > 5:
        recs.append("You have many small expenses; try bulk buying 🛒")
    return jsonify({"recommendations": recs})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 6000))
    app.run(host="0.0.0.0", port=port)